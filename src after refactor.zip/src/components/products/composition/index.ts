/**
 * ProductsPage composition glue - types and styles shared across tabs.
 */

export * from './types';
export * from './styles';
