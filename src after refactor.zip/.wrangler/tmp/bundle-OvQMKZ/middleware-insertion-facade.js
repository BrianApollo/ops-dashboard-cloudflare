				import worker, * as OTHER_EXPORTS from "C:\\Users\\Jay\\Desktop\\Jay\\ops-dashboard-cloudflare\\.wrangler\\tmp\\pages-LCXxOM\\functionsWorker-0.2904826102437217.mjs";
				import * as __MIDDLEWARE_0__ from "C:\\Users\\Jay\\Desktop\\Jay\\ops-dashboard-cloudflare\\node_modules\\wrangler\\templates\\middleware\\middleware-ensure-req-body-drained.ts";
import * as __MIDDLEWARE_1__ from "C:\\Users\\Jay\\Desktop\\Jay\\ops-dashboard-cloudflare\\node_modules\\wrangler\\templates\\middleware\\middleware-miniflare3-json-error.ts";

				export * from "C:\\Users\\Jay\\Desktop\\Jay\\ops-dashboard-cloudflare\\.wrangler\\tmp\\pages-LCXxOM\\functionsWorker-0.2904826102437217.mjs";

				export const __INTERNAL_WRANGLER_MIDDLEWARE__ = [
					
					__MIDDLEWARE_0__.default,__MIDDLEWARE_1__.default
				]
				export default worker;