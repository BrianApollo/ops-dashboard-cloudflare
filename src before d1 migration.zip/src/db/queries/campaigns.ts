/**
 * D1 Query Functions — Campaigns
 * READ-ONLY for Phase 3.
 */

import { eq } from 'drizzle-orm';
import type { DbClient } from '../client';
import { campaigns, campaignVideos, campaignImages } from '../schema';

export async function getAllCampaigns(db: DbClient) {
  const rows = await db.select().from(campaigns);
  const videoLinks = await db.select().from(campaignVideos);
  const imageLinks = await db.select().from(campaignImages);

  return rows.map((campaign) => ({
    ...campaign,
    videoIds: videoLinks
      .filter((v) => v.campaignId === campaign.id)
      .map((v) => v.videoId),
    imageIds: imageLinks
      .filter((i) => i.campaignId === campaign.id)
      .map((i) => i.imageId),
  }));
}

export async function getCampaignsByProduct(db: DbClient, productId: string) {
  const rows = await db
    .select()
    .from(campaigns)
    .where(eq(campaigns.productId, productId));

  const ids = rows.map((c) => c.id);
  if (ids.length === 0) return [];

  const videoLinks = await db.select().from(campaignVideos);
  const imageLinks = await db.select().from(campaignImages);

  return rows.map((campaign) => ({
    ...campaign,
    videoIds: videoLinks
      .filter((v) => v.campaignId === campaign.id)
      .map((v) => v.videoId),
    imageIds: imageLinks
      .filter((i) => i.campaignId === campaign.id)
      .map((i) => i.imageId),
  }));
}

export async function getCampaignById(db: DbClient, id: string) {
  const [campaign] = await db
    .select()
    .from(campaigns)
    .where(eq(campaigns.id, id));
  if (!campaign) return null;

  const videoLinks = await db
    .select()
    .from(campaignVideos)
    .where(eq(campaignVideos.campaignId, id));
  const imageLinks = await db
    .select()
    .from(campaignImages)
    .where(eq(campaignImages.campaignId, id));

  return {
    ...campaign,
    videoIds: videoLinks.map((v) => v.videoId),
    imageIds: imageLinks.map((i) => i.imageId),
  };
}
