/**
 * D1 Query Functions — Profiles (Infrastructure)
 * READ-ONLY for Phase 3.
 *
 * Returns profiles with their linked BMs, pages, ad accounts, and pixels
 * assembled from junction tables.
 */

import { eq } from 'drizzle-orm';
import type { DbClient } from '../client';
import {
  profiles,
  businessManagers,
  adAccounts,
  pages,
  pixels,
  profileBms,
  profilePages,
  bmAdAccounts,
  bmPixels,
  pixelOwnerBms,
} from '../schema';

/** Sensitive fields stripped for non-admin roles */
const SENSITIVE_FIELDS = [
  'permanentToken',
  'profileFbPassword',
  'profileEmailPassword',
  'profile2fa',
  'profileSecurityEmail',
  'securityEmailPassword',
] as const;

type ProfileRow = typeof profiles.$inferSelect;
type SanitizedProfile = Omit<ProfileRow, (typeof SENSITIVE_FIELDS)[number]>;

function sanitizeProfile(row: ProfileRow, isAdmin: boolean): SanitizedProfile | ProfileRow {
  if (isAdmin) return row;
  const safe = { ...row };
  for (const field of SENSITIVE_FIELDS) {
    delete (safe as Record<string, unknown>)[field];
  }
  return safe as SanitizedProfile;
}

/**
 * Fetch all infrastructure data in one call:
 * profiles → BMs → ad_accounts / pixels + pages
 */
export async function getInfrastructureData(db: DbClient, isAdmin: boolean) {
  // Fetch all tables in parallel
  const [
    profileRows,
    bmRows,
    adAccountRows,
    pageRows,
    pixelRows,
    profileBmRows,
    profilePageRows,
    bmAdAccountRows,
    bmPixelRows,
    pixelOwnerRows,
  ] = await Promise.all([
    db.select().from(profiles).where(eq(profiles.hidden, false)),
    db.select().from(businessManagers).where(eq(businessManagers.hidden, false)),
    db.select().from(adAccounts).where(eq(adAccounts.hidden, false)),
    db.select().from(pages).where(eq(pages.hidden, false)),
    db.select().from(pixels).where(eq(pixels.hidden, false)),
    db.select().from(profileBms),
    db.select().from(profilePages),
    db.select().from(bmAdAccounts),
    db.select().from(bmPixels),
    db.select().from(pixelOwnerBms),
  ]);

  // Strip sensitive fields from BMs for non-admin
  const sanitizedBms = bmRows.map((bm) => {
    if (isAdmin) return bm;
    const safe = { ...bm };
    delete (safe as Record<string, unknown>)['systemUserId'];
    delete (safe as Record<string, unknown>)['systemUserToken'];
    return safe;
  });

  // Index junction tables for O(1) lookup
  const bmAdAccountMap = new Map<string, string[]>();
  for (const { bmId, adAccountId } of bmAdAccountRows) {
    const list = bmAdAccountMap.get(bmId) ?? [];
    list.push(adAccountId);
    bmAdAccountMap.set(bmId, list);
  }

  const bmPixelMap = new Map<string, string[]>();
  for (const { bmId, pixelId } of bmPixelRows) {
    const list = bmPixelMap.get(bmId) ?? [];
    list.push(pixelId);
    bmPixelMap.set(bmId, list);
  }

  const pixelOwnerMap = new Map<string, string[]>();
  for (const { pixelId, bmId } of pixelOwnerRows) {
    const list = pixelOwnerMap.get(pixelId) ?? [];
    list.push(bmId);
    pixelOwnerMap.set(pixelId, list);
  }

  const profileBmMap = new Map<string, string[]>();
  for (const { profileId, bmId } of profileBmRows) {
    const list = profileBmMap.get(profileId) ?? [];
    list.push(bmId);
    profileBmMap.set(profileId, list);
  }

  const profilePageMap = new Map<string, string[]>();
  for (const { profileId, pageId } of profilePageRows) {
    const list = profilePageMap.get(profileId) ?? [];
    list.push(pageId);
    profilePageMap.set(profileId, list);
  }

  // Index entity maps
  const bmById = new Map(sanitizedBms.map((bm) => [bm.id, bm]));
  const adAccountById = new Map(adAccountRows.map((a) => [a.id, a]));
  const pageById = new Map(pageRows.map((p) => [p.id, p]));
  const pixelById = new Map(pixelRows.map((p) => [p.id, p]));

  // Assemble pixels with owner BM ids
  const pixelsWithOwners = pixelRows.map((pixel) => ({
    ...pixel,
    ownerBmIds: pixelOwnerMap.get(pixel.id) ?? [],
  }));
  const pixelWithOwnerById = new Map(pixelsWithOwners.map((p) => [p.id, p]));

  // Assemble BMs with their ad accounts and pixels
  const bmsWithChildren = sanitizedBms.map((bm) => ({
    ...bm,
    adAccounts: (bmAdAccountMap.get(bm.id) ?? [])
      .map((id) => adAccountById.get(id))
      .filter(Boolean),
    pixels: (bmPixelMap.get(bm.id) ?? [])
      .map((id) => pixelWithOwnerById.get(id))
      .filter(Boolean),
  }));
  const bmWithChildrenById = new Map(bmsWithChildren.map((bm) => [bm.id, bm]));

  // Assemble profiles with their BMs and pages
  const profilesWithChildren = profileRows.map((profile) => ({
    ...sanitizeProfile(profile, isAdmin),
    businessManagers: (profileBmMap.get(profile.id) ?? [])
      .map((id) => bmWithChildrenById.get(id))
      .filter(Boolean),
    pages: (profilePageMap.get(profile.id) ?? [])
      .map((id) => pageById.get(id))
      .filter(Boolean),
  }));

  return {
    profiles: profilesWithChildren,
    // Flat lists also returned for convenience
    allBusinessManagers: bmsWithChildren,
    allAdAccounts: adAccountRows,
    allPages: pageRows,
    allPixels: pixelsWithOwners,
  };
}

export async function getProfileById(db: DbClient, id: string, isAdmin: boolean) {
  const [profile] = await db.select().from(profiles).where(eq(profiles.id, id));
  if (!profile) return null;
  return sanitizeProfile(profile, isAdmin);
}
