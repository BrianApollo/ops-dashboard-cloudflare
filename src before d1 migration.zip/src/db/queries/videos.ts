/**
 * D1 Query Functions — Videos
 * READ-ONLY for Phase 3.
 */

import { eq } from 'drizzle-orm';
import type { DbClient } from '../client';
import { videos } from '../schema';

export async function getAllVideos(db: DbClient) {
  return db.select().from(videos);
}

export async function getVideosByProduct(db: DbClient, productId: string) {
  return db.select().from(videos).where(eq(videos.productId, productId));
}

export async function getVideosByEditor(db: DbClient, editorId: string) {
  return db.select().from(videos).where(eq(videos.editorId, editorId));
}

export async function getVideoById(db: DbClient, id: string) {
  const [row] = await db.select().from(videos).where(eq(videos.id, id));
  return row ?? null;
}
