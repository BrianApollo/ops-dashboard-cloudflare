/**
 * Auth domain - canonical exports
 *
 * Authentication-related pages and components.
 */

export { default as LoginPage } from './LoginPage';
