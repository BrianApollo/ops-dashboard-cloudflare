/**
 * OPS Infrastructure - canonical exports
 *
 * Components for viewing Facebook infrastructure health.
 */

export { InfrastructurePage } from './InfrastructurePage';
