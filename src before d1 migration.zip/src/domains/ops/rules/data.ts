/**
 * Scaling Rules data layer.
 * CRUD operations via the Airtable proxy at /api/airtable/Scaling Rules.
 */

import { airtableFetch } from '../../../core/data/airtable-client';
import type { ScalingRuleRecord, ScalingRule } from './types';
import { recordToRule } from './types';

const TABLE = 'Scaling Rules';

// =============================================================================
// FETCH ALL RULES
// =============================================================================

export async function fetchRules(): Promise<ScalingRule[]> {
  const params = new URLSearchParams();
  params.set('sort[0][field]', 'Name');
  params.set('sort[0][direction]', 'asc');

  const response = await airtableFetch(`${TABLE}?${params.toString()}`);
  const data = (await response.json()) as { records: ScalingRuleRecord[] };
  return (data.records || []).map(recordToRule);
}

// =============================================================================
// CREATE RULE
// =============================================================================

export async function createRule(
  fields: Record<string, unknown>,
): Promise<ScalingRule> {
  const response = await airtableFetch(TABLE, {
    method: 'POST',
    body: JSON.stringify({ fields }),
  });
  const data = (await response.json()) as ScalingRuleRecord;
  return recordToRule(data);
}

// =============================================================================
// UPDATE RULE
// =============================================================================

export async function updateRule(
  recordId: string,
  fields: Record<string, unknown>,
): Promise<ScalingRule> {
  const response = await airtableFetch(`${TABLE}/${recordId}`, {
    method: 'PATCH',
    body: JSON.stringify({ fields }),
  });
  const data = (await response.json()) as ScalingRuleRecord;
  return recordToRule(data);
}

// =============================================================================
// DELETE RULE
// =============================================================================

export async function deleteRule(recordId: string): Promise<void> {
  await airtableFetch(`${TABLE}/${recordId}`, {
    method: 'DELETE',
  });
}
