/**
 * OPS Videos - canonical exports
 *
 * Components for managing videos within the OPS workflow.
 */

export { VideosTab } from './VideosTab';
