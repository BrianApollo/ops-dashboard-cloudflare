/**
 * OPS Setup - canonical exports
 *
 * Components for product setup and ad presets management.
 */

export { SetupTab } from './SetupTab';
