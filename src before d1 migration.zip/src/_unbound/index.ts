/**
 * _unbound - Files without a clear domain home
 *
 * These files are placed here temporarily during restructuring.
 */

export { default as ForbiddenPage } from './ForbiddenPage';
